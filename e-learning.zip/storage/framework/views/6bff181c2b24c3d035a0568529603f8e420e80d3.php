<!-- Alert -->
<script>
    <?php if(Session::has('store')): ?>
        alertify.success("Data Berhasil Ditambahkan");
    <?php endif; ?>

    <?php if(Session::has('welcome')): ?>
        alertify.success("Selamat Datang Kembali, <?php echo e(auth()->user()->nama_lengkap); ?>!");
    <?php endif; ?>

    <?php if(Session::has('newWelcome')): ?>
        alertify.success("Selamat Datang, <?php echo e(auth()->user()->nama_lengkap); ?>!");
    <?php endif; ?>

    <?php if(Session::has('suksesPw')): ?>
        alertify.success("Kata Sandi Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('update')): ?>
        alertify.success("Data Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('destroy')): ?>
        alertify.success("Data Berhasil Dihapus");
    <?php endif; ?>

    <?php if(Session::has('verifikasi')): ?>
        alertify.success("Transaksi Berhasil Diverifikasi");
    <?php endif; ?>

    <?php if(Session::has('transaksi')): ?>
        alertify.success("Transaksi Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('profil')): ?>
        alertify.success("Profil Berhasil Diperbarui");
    <?php endif; ?>

    <?php if(Session::has('selesaiQuis')): ?>
        alertify.success("Anda Sudah Menyelsaikan Quis!");
    <?php endif; ?>

    <?php if(Session::has('ratingRequired')): ?>
        alertify.success("Lakukan Penilaian Terlebih Dahulu!");
    <?php endif; ?>
</script>
<?php /**PATH C:\xampp\htdocs\e-learning\resources\views/components/alert.blade.php ENDPATH**/ ?>