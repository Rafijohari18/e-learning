<footer class="bg_dark footer_dark">
    <div class="footer_top">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-2 col-md-4 col-sm-5">
                    <div class="widget">
                        <h6 class="widget_title">Program</h6>
                        <ul class="widget_links">
                            <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('detail.program', $prog->slug)); ?>"><?php echo e($prog->nama_program); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4 col-sm-5">
                    <div class="widget">
                        <h6 class="widget_title">Kategori</h6>
                        <ul class="widget_links">
                            <?php $__currentLoopData = $kategoriFt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kFt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($kFt->nama_kategori); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 col-sm-7">
                    <div class="widget">
                        <h6 class="widget_title">Informasi Terbaru</h6>
                        <ul class="widget_recent_post">
                            <li>
                                <div class="post_footer">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontenBaru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="post_img"> 
                                        <img src="<?php echo e(asset('storage/'.$kontenBaru->path)); ?>" alt="<?php echo e($kontenBaru->judul); ?>" width="50" height="40">
                                    </div>
                                    <div class="post_content">
                                        <h6><a href="<?php echo e(route('detail.informasi',$kontenBaru->slug)); ?>"><?php echo e($kontenBaru->judul); ?></a></h6>
                                        <p class="small m-0"><?php echo e($kontenBaru->created_at->format('d F Y')); ?></p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 col-sm-12">
                    <div class="widget">
                        <h6 class="widget_title">Kontak</h6>
                        <ul class="contact_info contact_info_light">
                            <li> 
                                <i class="ti-location-pin"></i>
                                <p><?php echo e($pengaturan->alamat); ?></p>
                            </li>
                            <li> 
                                <i class="ti-email"></i> 
                                <a href="mailto:<?php echo e($pengaturan->email); ?>"><?php echo e($pengaturan->email); ?></a> 
                            </li>
                            <li> 
                                <i class="ti-mobile"></i>
                                <p><?php echo e($pengaturan->no_tlp); ?></p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="bottom_footer border-top-tran">
                    <div class="row">
                        <div class="col-md-12">
                            <p class="mb-md-0 text-center text-md-left">© <?php echo e(date('Y')); ?> <span class="text_default"><?php echo e($pengaturan->footer); ?></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<ul class="jquin">
    <li>
        <a href="https://api.whatsapp.com/send?phone=6281214687886&amp;text=" target="_BLANK" class="whatsapp"><i class="fa fa-whatsapp"></i></a>
    </li>
    <li>
        <a href="mailto:<?php echo e($pengaturan->email); ?>" target="_BLANK" class="email"><i class="fa fa-envelope"></i></a>
    </li>
</ul>
<a href="#" class="scrollup" style="display: none;"><i class="ion-ios-arrow-up"></i></a> 

<!-- Latest jQuery --> 
<script src="<?php echo e(asset('landingpage/js/jquery-1.12.4.min.js')); ?>"></script> 
<!-- Latest compiled and minified Bootstrap --> 
<script src="<?php echo e(asset('landingpage/bootstrap/js/bootstrap.min.js')); ?>"></script> 
<!-- owl-carousel min js  --> 
<script src="<?php echo e(asset('landingpage/owlcarousel/js/owl.carousel.min.js')); ?>"></script> 
<!-- magnific-popup min js  --> 
<script src="<?php echo e(asset('landingpage/js/magnific-popup.min.js')); ?>"></script> 
<!-- waypoints min js  --> 
<script src="<?php echo e(asset('landingpage/js/waypoints.min.js')); ?>"></script> 
<!-- parallax js  --> 
<script src="<?php echo e(asset('landingpage/js/parallax.js')); ?>"></script> 
<!-- countdown js  --> 
<script src="<?php echo e(asset('landingpage/js/jquery.countdown.min.js')); ?>"></script> 
<!-- jquery.countTo js  --> 
<script src="<?php echo e(asset('landingpage/js/jquery.countTo.js')); ?>"></script> 
<!-- imagesloaded js --> 
<script src="<?php echo e(asset('landingpage/js/imagesloaded.pkgd.min.js')); ?>"></script> 
<!-- isotope min js --> 
<script src="<?php echo e(asset('landingpage/js/isotope.min.js')); ?>"></script> 
<!-- jquery.appear js  --> 
<script src="<?php echo e(asset('landingpage/js/jquery.appear.js')); ?>"></script> 
<!-- jquery.dd.min js --> 
<script src="<?php echo e(asset('landingpage/js/jquery.dd.min.js')); ?>"></script>
<!-- slick js -->
<script src="<?php echo e(asset('landingpage/js/slick.min.js')); ?>"></script> 
<!-- scripts js --> 
<script src="<?php echo e(asset('landingpage/js/scripts.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\e-learning\resources\views/components/lpfooter.blade.php ENDPATH**/ ?>